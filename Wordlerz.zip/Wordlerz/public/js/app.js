// Wordlerz Multiplayer & Solo - Client Controller
document.addEventListener('DOMContentLoaded', () => {
  // ==========================================
  // STATE MANAGEMENT
  // ==========================================
  const state = {
    view: 'home', // 'home' | 'solo' | 'lobby' | 'multiplayer-game'
    selectedMode: 'solo', // 'solo' | 'multiplayer'
    playerName: localStorage.getItem('contexto_username') || ('Player_' + Math.floor(1000 + Math.random() * 9000)),
    currentAvatar: window.avatarManager.getCurrentAvatar(),
    
    // Solo Mode State
    solo: {
      sessionId: null,
      guesses: [],
      hintsCount: 0,
      bestRank: null,
      startTime: null
    },

    // Multiplayer Mode State
    socket: null,
    mp: {
      roomCode: null,
      isHost: false,
      room: null,
      myGuesses: [],
      hintsCount: 0
    }
  };

  // ==========================================
  // DOM ELEMENTS
  // ==========================================
  // Views
  const views = {
    home: document.getElementById('home-view'),
    solo: document.getElementById('solo-view'),
    lobby: document.getElementById('lobby-view'),
    mpGame: document.getElementById('multiplayer-game-view')
  };

  // Header
  const btnLogoHome = document.getElementById('btn-logo-home');
  const btnHeaderHome = document.getElementById('btn-header-home');
  const btnSoundToggle = document.getElementById('btn-sound-toggle');
  const soundIcon = document.getElementById('sound-icon');

  // Home Screen Elements
  const homeAvatarDisplay = document.getElementById('home-avatar-display');
  const btnOpenAvatarModal = document.getElementById('btn-open-avatar-modal');
  const playerNameInput = document.getElementById('player-name-input');
  const cardModeSolo = document.getElementById('card-mode-solo');
  const cardModeMultiplayer = document.getElementById('card-mode-multiplayer');
  const btnMainPlay = document.getElementById('btn-main-play');

  // Modals
  const modalAvatar = document.getElementById('modal-avatar-settings');
  const btnCloseAvatarModal = document.getElementById('btn-close-avatar-modal');
  const avatarGridList = document.getElementById('avatar-grid-list');
  const btnSaveAvatar = document.getElementById('btn-save-avatar');

  const modalMpOptions = document.getElementById('modal-mp-options');
  const btnCloseMpModal = document.getElementById('btn-close-mp-modal');
  const btnOptCreateRoom = document.getElementById('btn-opt-create-room');
  const btnOptJoinCode = document.getElementById('btn-opt-join-code');
  const inputJoinCode = document.getElementById('input-join-code');
  const btnOptJoinRandom = document.getElementById('btn-opt-join-random');

  const modalHint = document.getElementById('modal-hint-dialog');
  const btnCloseHintModal = document.getElementById('btn-close-hint-modal');
  const hintModalContent = document.getElementById('hint-modal-content');
  const btnDismissHint = document.getElementById('btn-dismiss-hint');

  const modalCelebration = document.getElementById('modal-celebration');
  const winModalTitle = document.getElementById('win-modal-title');
  const winSecretWord = document.getElementById('win-secret-word');
  const winStatGuesses = document.getElementById('win-stat-guesses');
  const winStatTime = document.getElementById('win-stat-time');
  const winStatHints = document.getElementById('win-stat-hints');
  const btnWinReplay = document.getElementById('btn-win-replay');
  const btnWinHome = document.getElementById('btn-win-home');
  const btnMpNextRound = document.getElementById('btn-mp-next-round');

  // Solo Screen Elements
  const soloGuessesVal = document.getElementById('solo-guesses-val');
  const soloHintsVal = document.getElementById('solo-hints-val');
  const soloBestRank = document.getElementById('solo-best-rank');
  const btnSoloGiveup = document.getElementById('btn-solo-giveup');
  const soloGuessForm = document.getElementById('solo-guess-form');
  const soloWordInput = document.getElementById('solo-word-input');
  const btnSoloHint = document.getElementById('btn-solo-hint');
  const soloGuessesList = document.getElementById('solo-guesses-list');

  // Lobby Screen Elements
  const lobbyCodeDisplay = document.getElementById('lobby-code-display');
  const btnCopyRoomCode = document.getElementById('btn-copy-room-code');
  const lobbyPlayerCount = document.getElementById('lobby-player-count');
  const lobbyPlayersList = document.getElementById('lobby-players-list');
  const lobbyChatMessages = document.getElementById('lobby-chat-messages');
  const lobbyChatForm = document.getElementById('lobby-chat-form');
  const lobbyChatInput = document.getElementById('lobby-chat-input');
  const adminControlsPanel = document.getElementById('admin-controls-panel');
  const settingMaxPlayers = document.getElementById('setting-max-players');
  const settingTotalRounds = document.getElementById('setting-total-rounds');
  const settingPointsSystem = document.getElementById('setting-points-system');
  const btnAdminStartGame = document.getElementById('btn-admin-start-game');
  const playerWaitingNotice = document.getElementById('player-waiting-notice');

  // Multiplayer Game Elements
  const mpRoundIndicator = document.getElementById('mp-round-indicator');
  const mpGuessesVal = document.getElementById('mp-guesses-val');
  const mpHintsVal = document.getElementById('mp-hints-val');
  const mpRoomCodeTag = document.getElementById('mp-room-code-tag');
  const mpGuessForm = document.getElementById('mp-guess-form');
  const mpWordInput = document.getElementById('mp-word-input');
  const btnMpHint = document.getElementById('btn-mp-hint');
  const mpGuessesList = document.getElementById('mp-guesses-list');
  const mpLiveLeaderboard = document.getElementById('mp-live-leaderboard');
  const mpChatMessages = document.getElementById('mp-chat-messages');
  const mpChatForm = document.getElementById('mp-chat-form');
  const mpChatInput = document.getElementById('mp-chat-input');

  // ==========================================
  // INITIALIZATION & ROUTING
  // ==========================================
  function init() {
    playerNameInput.value = state.playerName;
    renderHomeAvatar();
    initAvatarModal();
    initSocket();

    // Check initial path for routing
    const path = window.location.pathname.toLowerCase();
    if (path.includes('solo')) {
      state.selectedMode = 'solo';
      updateModeSelectionUI('solo');
      startSoloGame();
    } else if (path.includes('multiplayer')) {
      state.selectedMode = 'multiplayer';
      updateModeSelectionUI('multiplayer');
      openModal(modalMpOptions);
    } else {
      switchView('home');
    }
  }

  function switchView(viewName) {
    state.view = viewName;
    Object.keys(views).forEach(v => {
      if (views[v]) views[v].classList.remove('active');
    });

    if (views[viewName]) {
      views[viewName].classList.add('active');
    }

    // Toggle header home button
    if (viewName === 'home') {
      btnHeaderHome.style.display = 'none';
      window.history.replaceState({}, '', '/');
    } else {
      btnHeaderHome.style.display = 'inline-flex';
      if (viewName === 'solo') window.history.replaceState({}, '', '/solo');
      if (viewName === 'lobby' || viewName === 'mpGame') window.history.replaceState({}, '', '/multiplayer');
    }
  }

  function renderHomeAvatar() {
    homeAvatarDisplay.innerHTML = window.avatarManager.renderAvatarHtml(state.currentAvatar.id, 72);
  }

  // ==========================================
  // AVATAR SETTINGS
  // ==========================================
  let selectedAvatarInModal = state.currentAvatar.id;

  function initAvatarModal() {
    avatarGridList.innerHTML = '';
    window.AVATAR_LIST.forEach(avatar => {
      const item = document.createElement('div');
      item.className = `avatar-grid-item ${avatar.id === selectedAvatarInModal ? 'active' : ''}`;
      item.innerHTML = `
        ${window.avatarManager.renderAvatarHtml(avatar.id, 48)}
        <span class="avatar-label">${avatar.label}</span>
      `;
      item.addEventListener('click', () => {
        selectedAvatarInModal = avatar.id;
        document.querySelectorAll('.avatar-grid-item').forEach(el => el.classList.remove('active'));
        item.classList.add('active');
      });
      avatarGridList.appendChild(item);
    });
  }

  btnOpenAvatarModal.addEventListener('click', () => {
    selectedAvatarInModal = state.currentAvatar.id;
    initAvatarModal();
    openModal(modalAvatar);
  });

  btnCloseAvatarModal.addEventListener('click', () => closeModal(modalAvatar));
  
  btnSaveAvatar.addEventListener('click', () => {
    state.currentAvatar = window.avatarManager.setAvatar(selectedAvatarInModal);
    renderHomeAvatar();
    closeModal(modalAvatar);
  });

  // Name Input Change
  playerNameInput.addEventListener('input', (e) => {
    state.playerName = e.target.value.trim() || 'Player';
    localStorage.setItem('contexto_username', state.playerName);
  });

  // Mode Selection Cards
  function updateModeSelectionUI(mode) {
    state.selectedMode = mode;
    if (mode === 'solo') {
      cardModeSolo.classList.add('selected');
      cardModeMultiplayer.classList.remove('selected');
    } else {
      cardModeMultiplayer.classList.add('selected');
      cardModeSolo.classList.remove('selected');
    }
  }

  cardModeSolo.addEventListener('click', () => updateModeSelectionUI('solo'));
  cardModeMultiplayer.addEventListener('click', () => updateModeSelectionUI('multiplayer'));

  // Main Play Button
  btnMainPlay.addEventListener('click', () => {
    if (state.selectedMode === 'solo') {
      startSoloGame();
    } else {
      openModal(modalMpOptions);
    }
  });

  // Navigation Buttons
  btnLogoHome.addEventListener('click', () => switchView('home'));
  btnHeaderHome.addEventListener('click', () => switchView('home'));

  // Sound Toggle
  btnSoundToggle.addEventListener('click', () => {
    window.soundFX.muted = !window.soundFX.muted;
    soundIcon.textContent = window.soundFX.muted ? '🔇' : '🔊';
  });

  // Modal helpers
  function openModal(modal) {
    if (modal) modal.classList.add('active');
  }
  function closeModal(modal) {
    if (modal) modal.classList.remove('active');
  }

  // ==========================================
  // SOLO MODE IMPLEMENTATION
  // ==========================================
  async function startSoloGame() {
    switchView('solo');
    soloWordInput.value = '';
    soloWordInput.focus();
    soloGuessesList.innerHTML = '';
    soloGuessesVal.textContent = '0';
    soloHintsVal.textContent = '0';
    soloBestRank.textContent = '-';

    try {
      const res = await fetch('/api/solo/start', { method: 'POST' });
      const data = await res.json();
      state.solo.sessionId = data.sessionId;
      state.solo.guesses = [];
      state.solo.hintsCount = 0;
      state.solo.bestRank = null;
      state.solo.startTime = Date.now();
    } catch (err) {
      alert("Error starting solo game: " + err.message);
    }
  }

  soloGuessForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const word = soloWordInput.value.trim();
    if (!word) return;

    soloWordInput.value = '';
    soloWordInput.focus();

    try {
      const res = await fetch('/api/solo/guess', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: state.solo.sessionId, word })
      });
      const data = await res.json();

      if (data.error) {
        alert(data.error);
        return;
      }

      state.solo.guesses = data.guesses;
      state.solo.hintsCount = data.hintsCount;
      state.solo.bestRank = data.bestRank;

      soloGuessesVal.textContent = data.guessesCount;
      soloBestRank.textContent = '#' + data.bestRank;

      // Play audio feedback
      window.soundFX.playRankSound(data.evaluation.rank);

      // Render Guesses List
      renderGuesses(soloGuessesList, data.guesses, data.evaluation.word);

      // Check Win
      if (data.winStats) {
        triggerVictory(data.winStats, false);
      }
    } catch (err) {
      console.error(err);
    }
  });

  // Solo Hint Button
  btnSoloHint.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/solo/hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: state.solo.sessionId })
      });
      const data = await res.json();

      if (data.success && data.hint) {
        soloHintsVal.textContent = data.hintsCount;
        showHintModal(data.hint);
      }
    } catch (err) {
      console.error(err);
    }
  });

  // Solo Give Up Button
  btnSoloGiveup.addEventListener('click', async () => {
    if (!confirm("Are you sure you want to give up and reveal the secret word?")) return;
    try {
      const res = await fetch('/api/solo/giveup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: state.solo.sessionId })
      });
      const data = await res.json();
      if (data.success) {
        alert(`The secret word was: "${data.secretWord.toUpperCase()}".\nCategory: ${data.properties.category}\nTraits: ${data.properties.characteristics}`);
        startSoloGame();
      }
    } catch (err) {
      console.error(err);
    }
  });

  // ==========================================
  // MULTIPLAYER SOCKET SETUP & LOBBY
  // ==========================================
  function initSocket() {
    if (state.socket) return;
    state.socket = io();

    // Connection status feedback
    state.socket.on('connect', () => {
      console.log('[Wordlerz] Connected to server, socket id:', state.socket.id);
    });

    state.socket.on('connect_error', (err) => {
      console.error('[Wordlerz] Socket connection error:', err.message);
      showToast('⚠️ Cannot connect to server. Is the game server running?', 'error');
    });

    state.socket.on('disconnect', (reason) => {
      console.warn('[Wordlerz] Disconnected:', reason);
      if (state.view !== 'home' && state.view !== 'solo') {
        showToast('⚠️ Disconnected from server. Trying to reconnect...', 'error');
      }
    });

    // Real-time events: room_updated — re-render lobby WITH self-awareness
    state.socket.on('room_updated', (data) => {
      state.mp.room = data.room;
      // Inject isSelf flag before rendering
      const enriched = enrichRoomWithSelf(data.room);
      renderLobby(enriched);
      if (data.systemMessage) {
        appendChatMessage(lobbyChatMessages, { isSystem: true, text: data.systemMessage });
      }
    });

    state.socket.on('chat_message', (msg) => {
      appendChatMessage(lobbyChatMessages, msg);
      appendChatMessage(mpChatMessages, msg);
      window.soundFX.playChat();
    });

    state.socket.on('admin_changed', (data) => {
      if (data.newAdminId === state.socket.id) {
        state.mp.isHost = true;
        adminControlsPanel.style.display = 'flex';
        playerWaitingNotice.style.display = 'none';
      }
      appendChatMessage(lobbyChatMessages, { isSystem: true, text: `${data.newAdminName} is now the host.` });
    });

    state.socket.on('game_started', (data) => {
      state.mp.room = data.room;
      startMultiplayerGameView();
    });

    state.socket.on('leaderboard_updated', (data) => {
      renderLeaderboard(data.leaderboard);
    });

    state.socket.on('round_winner', (data) => {
      state.mp.room = data.room;
      renderLeaderboard(data.leaderboard);
      triggerVictory({
        secretWord: data.winner.secretWord,
        totalGuesses: data.winner.totalGuesses,
        timeTakenSec: data.winner.timeTakenSec,
        hintsTaken: data.winner.hintsTaken,
        winnerName: data.winner.playerName
      }, true);
    });

    state.socket.on('new_round_started', (data) => {
      closeModal(modalCelebration);
      state.mp.room = data.room;
      state.mp.myGuesses = [];
      mpGuessesList.innerHTML = '';
      mpGuessesVal.textContent = '0';
      mpHintsVal.textContent = '0';
      mpRoundIndicator.textContent = `Round ${data.currentRound}/${data.totalRounds}`;
      renderLeaderboard(data.room.players);
      mpWordInput.focus();
    });

    state.socket.on('game_over', (data) => {
      triggerGameOver(data.finalLeaderboard);
    });
  }

  // Multiplayer Dialog Option Handlers
  btnCloseMpModal.addEventListener('click', () => closeModal(modalMpOptions));

  // Auto uppercase the join code as user types
  inputJoinCode.addEventListener('input', (e) => {
    const pos = e.target.selectionStart;
    e.target.value = e.target.value.toUpperCase();
    e.target.setSelectionRange(pos, pos);
  });

  // Allow pressing Enter inside the code input to trigger join
  inputJoinCode.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      btnOptJoinCode.click();
    }
  });

  // 1. Create Room
  btnOptCreateRoom.addEventListener('click', () => {
    btnOptCreateRoom.disabled = true;
    btnOptCreateRoom.textContent = 'Creating...';
    state.socket.emit('create_room', {
      hostName: state.playerName,
      hostAvatar: state.currentAvatar.id,
      maxPlayers: settingMaxPlayers.value,
      totalRounds: settingTotalRounds.value,
      pointsSystem: settingPointsSystem.value
    }, (res) => {
      btnOptCreateRoom.disabled = false;
      btnOptCreateRoom.innerHTML = '<div style="font-size:2.2rem">👑</div><div><div style="font-weight:700;font-size:1.1rem">Create Room</div><div style="font-size:0.85rem;color:var(--text-muted)">Become host, customize rounds, max players & rules.</div></div>';
      if (res.error) {
        showToast('❌ ' + res.error, 'error');
        return;
      }
      state.mp.roomCode = res.room.code;
      state.mp.isHost = true;
      state.mp.room = res.room;
      closeModal(modalMpOptions);
      switchView('lobby');
      renderLobby(res.room);
    });
  });

  // 2. Join with Code
  btnOptJoinCode.addEventListener('click', async () => {
    const code = inputJoinCode.value.trim().toUpperCase();
    if (code.length < 4) {
      showToast('⚠️ Please enter a valid room code (at least 4 characters)', 'warn');
      inputJoinCode.focus();
      return;
    }
    btnOptJoinCode.disabled = true;
    btnOptJoinCode.textContent = 'Checking...';

    // Step 1: REST pre-check to give instant, clear error feedback
    try {
      const checkRes = await fetch(`/api/room/${code}`);
      const checkData = await checkRes.json();
      if (!checkData.exists) {
        btnOptJoinCode.disabled = false;
        btnOptJoinCode.textContent = 'Join';
        showToast(`❌ ${checkData.error}`, 'error');
        inputJoinCode.select();
        return;
      }
      if (checkData.isFull) {
        btnOptJoinCode.disabled = false;
        btnOptJoinCode.textContent = 'Join';
        showToast(`❌ Room ${code} is full (${checkData.playersCount}/${checkData.maxPlayers} players).`, 'error');
        return;
      }
    } catch (e) {
      // Server may not be reachable — fall through to socket attempt anyway
    }

    // Step 2: Actually join via Socket.io
    btnOptJoinCode.textContent = 'Joining...';
    state.socket.emit('join_room', {
      roomCode: code,
      playerName: state.playerName,
      playerAvatar: state.currentAvatar.id
    }, (res) => {
      btnOptJoinCode.disabled = false;
      btnOptJoinCode.textContent = 'Join';
      if (res.error) {
        // Keep modal OPEN so user can try again with a different code
        showToast('❌ ' + res.error, 'error');
        inputJoinCode.focus();
        return;
      }
      state.mp.roomCode = res.room.code;
      state.mp.isHost = res.isHost;
      state.mp.room = res.room;
      closeModal(modalMpOptions);
      inputJoinCode.value = '';
      switchView('lobby');
      renderLobby(enrichRoomWithSelf(res.room));
      showToast('✅ Joined room ' + res.room.code + '!', 'info');
    });
  });

  // 3. Join Random
  btnOptJoinRandom.addEventListener('click', () => {
    btnOptJoinRandom.disabled = true;
    btnOptJoinRandom.innerHTML = '<div style="font-size:2.2rem">🌍</div><div><div style="font-weight:700;font-size:1.1rem">Finding game...</div></div>';
    state.socket.emit('join_random', {
      playerName: state.playerName,
      playerAvatar: state.currentAvatar.id
    }, (res) => {
      btnOptJoinRandom.disabled = false;
      btnOptJoinRandom.innerHTML = '<div style="font-size:2.2rem">🌍</div><div><div style="font-weight:700;font-size:1.1rem">Join Random Game</div><div style="font-size:0.85rem;color:var(--text-muted)">Quick-match to an open room running worldwide.</div></div>';
      if (res.error) {
        showToast('❌ ' + res.error, 'error');
        return;
      }
      state.mp.roomCode = res.room.code;
      state.mp.isHost = res.isHost;
      state.mp.room = res.room;
      closeModal(modalMpOptions);
      switchView('lobby');
      renderLobby(enrichRoomWithSelf(res.room));
    });
  });

  // Copy Party Code
  btnCopyRoomCode.addEventListener('click', () => {
    if (state.mp.roomCode) {
      navigator.clipboard.writeText(state.mp.roomCode);
      alert(`Party Code "${state.mp.roomCode}" copied to clipboard!`);
    }
  });

  // Host Updates Settings
  [settingMaxPlayers, settingTotalRounds, settingPointsSystem].forEach(el => {
    el.addEventListener('change', () => {
      if (!state.mp.isHost) return;
      state.socket.emit('update_settings', {
        roomCode: state.mp.roomCode,
        settings: {
          maxPlayers: settingMaxPlayers.value,
          totalRounds: settingTotalRounds.value,
          pointsSystem: settingPointsSystem.value
        }
      });
    });
  });

  // Host Starts Game
  btnAdminStartGame.addEventListener('click', () => {
    if (!state.mp.isHost) return;
    state.socket.emit('start_game', { roomCode: state.mp.roomCode });
  });

  // Render Lobby UI
  function renderLobby(room) {
    if (!room) return;
    // Always ensure isSelf is set correctly, even on broadcast updates
    const enriched = enrichRoomWithSelf(room);
    lobbyCodeDisplay.textContent = enriched.code;
    lobbyPlayerCount.textContent = `${enriched.playersCount} / ${enriched.settings.maxPlayers}`;

    // Render Players
    lobbyPlayersList.innerHTML = '';
    enriched.players.forEach(p => {
      const item = document.createElement('div');
      item.className = 'player-lobby-item';
      item.innerHTML = `
        <div class="player-info">
          ${window.avatarManager.renderAvatarHtml(p.avatar, 36)}
          <span class="player-name-text">${p.name}${p.isSelf ? ' <em style="color:#38bdf8;font-style:normal;">(You)</em>' : ''}</span>
        </div>
        ${p.isAdmin ? '<span class="badge-host">HOST</span>' : ''}
      `;
      lobbyPlayersList.appendChild(item);
    });

    // Admin Controls vs Waiting Notice
    if (state.mp.isHost) {
      adminControlsPanel.style.display = 'flex';
      playerWaitingNotice.style.display = 'none';
      settingMaxPlayers.value = enriched.settings.maxPlayers;
      settingTotalRounds.value = enriched.settings.totalRounds;
      settingPointsSystem.value = enriched.settings.pointsSystem;
    } else {
      adminControlsPanel.style.display = 'none';
      playerWaitingNotice.style.display = 'block';
    }
  }

  // Lobby Chat Submissions (NO BOTS, Human only)
  lobbyChatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = lobbyChatInput.value.trim();
    if (!text) return;
    lobbyChatInput.value = '';
    state.socket.emit('send_chat', { roomCode: state.mp.roomCode, text });
  });

  mpChatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = mpChatInput.value.trim();
    if (!text) return;
    mpChatInput.value = '';
    state.socket.emit('send_chat', { roomCode: state.mp.roomCode, text });
  });

  function appendChatMessage(container, msg) {
    if (!container) return;
    const bubble = document.createElement('div');
    if (msg.isSystem) {
      bubble.className = 'chat-bubble system';
      bubble.textContent = msg.text;
    } else {
      bubble.className = 'chat-bubble';
      bubble.innerHTML = `
        <span class="chat-sender">${msg.senderName}</span>
        <span>${msg.text}</span>
      `;
    }
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
  }

  // ==========================================
  // MULTIPLAYER ACTIVE GAMEPLAY
  // ==========================================
  function startMultiplayerGameView() {
    switchView('mpGame');
    state.mp.myGuesses = [];
    state.mp.hintsCount = 0;
    mpGuessesList.innerHTML = '';
    mpGuessesVal.textContent = '0';
    mpHintsVal.textContent = '0';
    mpRoomCodeTag.textContent = state.mp.roomCode;
    mpRoundIndicator.textContent = `Round ${state.mp.room.currentRound}/${state.mp.room.settings.totalRounds}`;
    mpWordInput.value = '';
    mpWordInput.focus();

    renderLeaderboard(state.mp.room.players);
  }

  // MP Guess Form
  mpGuessForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const word = mpWordInput.value.trim();
    if (!word) return;
    mpWordInput.value = '';
    mpWordInput.focus();

    state.socket.emit('submit_guess', {
      roomCode: state.mp.roomCode,
      word
    }, (res) => {
      if (res.error) {
        alert(res.error);
        return;
      }

      state.mp.myGuesses = res.guesses;
      mpGuessesVal.textContent = res.guessesCount;
      mpHintsVal.textContent = res.hintsCount;

      window.soundFX.playRankSound(res.evaluation.rank);
      renderGuesses(mpGuessesList, res.guesses, res.evaluation.word);
    });
  });

  // MP Hint Button
  btnMpHint.addEventListener('click', () => {
    state.socket.emit('request_hint', { roomCode: state.mp.roomCode }, (res) => {
      if (res.error) {
        alert(res.error);
        return;
      }
      if (res.hint) {
        mpHintsVal.textContent = res.hintsCount;
        showHintModal(res.hint);
      }
    });
  });

  // MP Render Leaderboard
  function renderLeaderboard(playersList) {
    if (!mpLiveLeaderboard || !playersList) return;
    mpLiveLeaderboard.innerHTML = '';

    playersList.forEach((p, idx) => {
      const row = document.createElement('div');
      const isSelf = p.id === state.socket.id || p.isSelf;
      row.className = `leaderboard-row ${isSelf ? 'current-user' : ''}`;

      let rankClass = 'red';
      if (p.currentBestRank !== '-') {
        if (p.currentBestRank <= 500) rankClass = 'green';
        else if (p.currentBestRank <= 1000) rankClass = 'orange';
      }

      row.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          <span style="font-weight: 800; font-size: 0.9rem; color: var(--text-muted); width: 18px;">${idx + 1}</span>
          ${window.avatarManager.renderAvatarHtml(p.avatar, 30)}
          <div>
            <div style="font-size: 0.85rem; font-weight: 700;">${p.name} ${isSelf ? '(You)' : ''}</div>
            <div style="font-size: 0.72rem; color: var(--text-muted);">${p.guessesCount} guesses • ${p.score || 0} pts</div>
          </div>
        </div>
        <div class="leaderboard-rank-tag ${rankClass}">
          ${p.currentBestRank === '-' ? '-' : '#' + p.currentBestRank}
        </div>
      `;
      mpLiveLeaderboard.appendChild(row);
    });
  }

  // ==========================================
  // SHARED RENDERING HELPERS
  // ==========================================
  // Render Contexto Guess Bars
  function renderGuesses(container, guesses, latestWord) {
    container.innerHTML = '';

    guesses.forEach(g => {
      const row = document.createElement('div');
      const isWinner = g.rank === 1;
      row.className = `guess-item ${g.color} ${isWinner ? 'winner-row' : ''}`;

      row.innerHTML = `
        <div class="guess-progress-bar" style="width: ${g.percentage}%;"></div>
        <span class="guess-word">${g.word}</span>
        <span class="guess-rank">
          ${isWinner ? '🎉 #1' : '#' + g.rank}
        </span>
      `;

      container.appendChild(row);
    });
  }

  // Hint Modal Helper
  function showHintModal(hint) {
    hintModalContent.innerHTML = `
      <div style="font-weight: 800; margin-bottom: 0.5rem; color: #fde047;">${hint.title}</div>
      <div>${hint.text}</div>
    `;
    openModal(modalHint);
  }
  btnCloseHintModal.addEventListener('click', () => closeModal(modalHint));
  btnDismissHint.addEventListener('click', () => closeModal(modalHint));

  // Victory Celebration Helper
  function triggerVictory(stats, isMultiplayer = false) {
    window.confetti.trigger(4500);
    window.soundFX.playWinFanfare();

    winSecretWord.textContent = stats.secretWord.toUpperCase();
    winStatGuesses.textContent = stats.totalGuesses;
    winStatTime.textContent = stats.timeTakenSec + 's';
    winStatHints.textContent = stats.hintsTaken;

    if (isMultiplayer) {
      winModalTitle.textContent = `${stats.winnerName} Found The Secret Word!`;
      if (state.mp.isHost) {
        btnMpNextRound.style.display = 'block';
        btnMpNextRound.onclick = () => {
          state.socket.emit('next_round', { roomCode: state.mp.roomCode });
        };
      } else {
        btnMpNextRound.style.display = 'none';
      }
    } else {
      winModalTitle.textContent = "You Found The Secret Word!";
      btnMpNextRound.style.display = 'none';
    }

    openModal(modalCelebration);
  }

  // Final Game Over Modal
  function triggerGameOver(finalLeaderboard) {
    window.confetti.trigger(6000);
    const champion = finalLeaderboard[0];
    winModalTitle.textContent = `🏆 Match Over! Champion: ${champion.name}`;
    winSecretWord.textContent = `${champion.score} Points`;
    winStatGuesses.textContent = champion.guessesCount;
    winStatTime.textContent = 'Final';
    winStatHints.textContent = champion.hintsCount;
    btnMpNextRound.style.display = 'none';
    openModal(modalCelebration);
  }

  btnWinReplay.addEventListener('click', () => {
    closeModal(modalCelebration);
    if (state.view === 'solo') {
      startSoloGame();
    } else {
      switchView('lobby');
    }
  });

  btnWinHome.addEventListener('click', () => {
    closeModal(modalCelebration);
    switchView('home');
  });

  // ==========================================
  // UTILITY HELPERS
  // ==========================================

  // Mark the current player as "self" in a room's player list
  function enrichRoomWithSelf(room) {
    if (!room || !state.socket) return room;
    const myId = state.socket.id;
    const enriched = { ...room };
    enriched.players = (room.players || []).map(p => ({
      ...p,
      isSelf: p.id === myId
    }));
    return enriched;
  }

  // Toast notification (non-blocking, replaces alert for errors)
  function showToast(message, type = 'info') {
    const existing = document.getElementById('wordlerz-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'wordlerz-toast';
    const bg = type === 'error' ? '#ef4444' : type === 'warn' ? '#f59e0b' : '#10b981';
    toast.style.cssText = `
      position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
      background: ${bg}; color: white; padding: 0.8rem 1.6rem;
      border-radius: 12px; font-weight: 700; font-size: 0.95rem;
      z-index: 10000; box-shadow: 0 8px 24px rgba(0,0,0,0.5);
      animation: fadeIn 0.2s ease; max-width: 90vw; text-align: center;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
  }

  // Start initialization
  init();
});
