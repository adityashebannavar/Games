// Avatars Collection and Manager
const AVATAR_LIST = [
  { id: 'fox', emoji: '🦊', label: 'Clever Fox', bg: 'linear-gradient(135deg, #f97316, #ea580c)' },
  { id: 'cat', emoji: '🐱', label: 'Sneaky Cat', bg: 'linear-gradient(135deg, #ec4899, #db2777)' },
  { id: 'owl', emoji: '🦉', label: 'Wise Owl', bg: 'linear-gradient(135deg, #8b5cf6, #7c3aed)' },
  { id: 'dragon', emoji: '🐲', label: 'Mystic Dragon', bg: 'linear-gradient(135deg, #10b981, #059669)' },
  { id: 'tiger', emoji: '🐯', label: 'Bold Tiger', bg: 'linear-gradient(135deg, #f59e0b, #d97706)' },
  { id: 'panda', emoji: '🐼', label: 'Zen Panda', bg: 'linear-gradient(135deg, #64748b, #334155)' },
  { id: 'alien', emoji: '👽', label: 'Cosmic Alien', bg: 'linear-gradient(135deg, #06b6d4, #0891b2)' },
  { id: 'robot', emoji: '🤖', label: 'Cyber Bot', bg: 'linear-gradient(135deg, #3b82f6, #2563eb)' },
  { id: 'bear', emoji: '🐻', label: 'Grizzly', bg: 'linear-gradient(135deg, #a16207, #713f12)' },
  { id: 'wizard', emoji: '🧙‍♂️', label: 'Mage', bg: 'linear-gradient(135deg, #9333ea, #6b21a8)' },
  { id: 'ninja', emoji: '🥷', label: 'Shadow Ninja', bg: 'linear-gradient(135deg, #1e293b, #0f172a)' },
  { id: 'unicorn', emoji: '🦄', label: 'Star Unicorn', bg: 'linear-gradient(135deg, #f43f5e, #be123c)' }
];

class AvatarManager {
  constructor() {
    this.currentAvatarId = localStorage.getItem('contexto_avatar') || 'fox';
  }

  getCurrentAvatar() {
    return AVATAR_LIST.find(a => a.id === this.currentAvatarId) || AVATAR_LIST[0];
  }

  setAvatar(id) {
    const found = AVATAR_LIST.find(a => a.id === id);
    if (found) {
      this.currentAvatarId = id;
      localStorage.setItem('contexto_avatar', id);
    }
    return this.getCurrentAvatar();
  }

  renderAvatarHtml(avatarId, size = 48) {
    const avatar = AVATAR_LIST.find(a => a.id === avatarId) || AVATAR_LIST[0];
    const fontSize = Math.round(size * 0.58);
    return `
      <div class="player-avatar-badge" style="
        width: ${size}px;
        height: ${size}px;
        min-width: ${size}px;
        border-radius: 50%;
        background: ${avatar.bg};
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: ${fontSize}px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.25);
        user-select: none;
      " title="${avatar.label}">
        ${avatar.emoji}
      </div>
    `;
  }
}

window.avatarManager = new AvatarManager();
window.AVATAR_LIST = AVATAR_LIST;
