// Web Audio API Synthesizer for instant sound effects
class SoundFX {
  constructor() {
    this.ctx = null;
    this.muted = false;
  }

  ensureContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playTone(freq, type = 'sine', duration = 0.15, gainVal = 0.1) {
    if (this.muted) return;
    this.ensureContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      // Audio context may require user gesture
    }
  }

  // Guess feedback sounds
  playRankSound(rank) {
    if (this.muted) return;
    if (rank === 1) {
      this.playWinFanfare();
    } else if (rank <= 100) {
      // Very close: high bright double-bell
      this.playTone(880, 'triangle', 0.2, 0.12);
      setTimeout(() => this.playTone(1174, 'triangle', 0.3, 0.15), 100);
    } else if (rank <= 500) {
      // Green (1-500)
      this.playTone(659.25, 'triangle', 0.25, 0.12);
    } else if (rank <= 1000) {
      // Orange (501-1000)
      this.playTone(440, 'sine', 0.2, 0.1);
    } else {
      // Red (> 1000)
      this.playTone(260, 'sine', 0.15, 0.08);
    }
  }

  playWinFanfare() {
    if (this.muted) return;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C E G C
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        this.playTone(freq, 'triangle', 0.4, 0.18);
      }, idx * 120);
    });
  }

  playChat() {
    this.playTone(520, 'sine', 0.1, 0.05);
  }
}

window.soundFX = new SoundFX();
