@echo off
title Wordlerz - Full Stack Guess Game
cd /d "%~dp0"

echo ========================================================
echo   Starting Wordlerz Game Server and Opening Browser...
echo ========================================================

:: Check if Node is in PATH
where node >nul 2>&1
if %errorlevel% equ 0 (
    set "NODE_CMD=node"
    goto :run_server
)

:: Check standard install locations
if exist "C:\Program Files\nodejs\node.exe" (
    set "NODE_CMD=C:\Program Files\nodejs\node.exe"
    goto :run_server
)

if exist "C:\Program Files (x86)\nodejs\node.exe" (
    set "NODE_CMD=C:\Program Files (x86)\nodejs\node.exe"
    goto :run_server
)

if exist "%LOCALAPPDATA%\Programs\node\node.exe" (
    set "NODE_CMD=%LOCALAPPDATA%\Programs\node\node.exe"
    goto :run_server
)

echo [ERROR] Node.js executable could not be found!
echo Please make sure Node.js is installed.
pause
exit /b 1

:run_server
echo Node found: %NODE_CMD%
"%NODE_CMD%" server/index.js
pause
