const { SECRET_WORDS, CATEGORY_CLUSTERS } = require('./wordsData');

class SemanticEngine {
  constructor() {
    this.words = SECRET_WORDS;
  }

  // Get a random secret word object
  getRandomSecretWord() {
    const randomIndex = Math.floor(Math.random() * this.words.length);
    return this.words[randomIndex];
  }

  // Find secret word by string
  getSecretWord(wordStr) {
    const clean = wordStr.toLowerCase().trim();
    return this.words.find(w => w.word.toLowerCase() === clean) || this.getRandomSecretWord();
  }

  // Simple deterministic hash for a string and seed
  hashString(str, seed = 42) {
    let hash = seed;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  // Calculate semantic rank for a guess given a secret word
  evaluateGuess(guessRaw, secretWordObj) {
    if (!guessRaw || typeof guessRaw !== 'string') {
      return { error: "Please enter a valid word" };
    }

    const guess = guessRaw.toLowerCase().trim().replace(/[^a-z]/g, '');
    if (!guess || guess.length === 0) {
      return { error: "Invalid word characters" };
    }

    const secret = secretWordObj.word.toLowerCase();

    // 1. Exact Match -> WINNER (Rank 1)
    if (guess === secret) {
      return {
        word: guess,
        rank: 1,
        color: "green",
        percentage: 100,
        isWin: true,
        properties: {
          category: secretWordObj.category,
          nature: secretWordObj.nature,
          shape: secretWordObj.shape,
          color: secretWordObj.color,
          characteristics: secretWordObj.characteristics
        }
      };
    }

    // 2. Check predefined green immediate tiers (2 to 180)
    const immediate = secretWordObj.tiers.green_immediate || [];
    const immIndex = immediate.findIndex(w => w.toLowerCase() === guess);
    if (immIndex !== -1) {
      const step = Math.floor(178 / Math.max(immediate.length, 1));
      const rank = 2 + (immIndex * step) + (this.hashString(guess, 11) % step);
      return {
        word: guess,
        rank: Math.max(2, Math.min(200, rank)),
        color: "green",
        percentage: this.calculatePercentage(rank),
        isWin: false
      };
    }

    // 3. Check predefined green close tiers (201 to 499)
    const close = secretWordObj.tiers.green_close || [];
    const closeIndex = close.findIndex(w => w.toLowerCase() === guess);
    if (closeIndex !== -1) {
      const step = Math.floor(298 / Math.max(close.length, 1));
      const rank = 201 + (closeIndex * step) + (this.hashString(guess, 22) % step);
      return {
        word: guess,
        rank: Math.max(201, Math.min(499, rank)),
        color: "green",
        percentage: this.calculatePercentage(rank),
        isWin: false
      };
    }

    // 4. Check predefined orange moderate tiers (500 to 999)
    const moderate = secretWordObj.tiers.orange_moderate || [];
    const modIndex = moderate.findIndex(w => w.toLowerCase() === guess);
    if (modIndex !== -1) {
      const step = Math.floor(498 / Math.max(moderate.length, 1));
      const rank = 500 + (modIndex * step) + (this.hashString(guess, 33) % step);
      return {
        word: guess,
        rank: Math.max(500, Math.min(999, rank)),
        color: "orange",
        percentage: this.calculatePercentage(rank),
        isWin: false
      };
    }

    // 5. Dynamic semantic scoring for all other words (Ranks 1000+)
    // Check category affinity
    const categoryKeywords = CATEGORY_CLUSTERS[secretWordObj.category] || [];
    let affinityScore = 0;

    for (const kw of categoryKeywords) {
      if (guess.includes(kw) || kw.includes(guess)) {
        affinityScore += 30;
      }
    }

    // Morphological / common character overlap
    let commonChars = 0;
    const secretChars = new Set(secret.split(''));
    for (const char of guess) {
      if (secretChars.has(char)) commonChars++;
    }
    const charRatio = commonChars / Math.max(guess.length, secret.length);

    // Dynamic rank computation
    // Range: 1000 to ~20000
    const hashMod = this.hashString(guess + secret, 999) % 5000;
    let baseRank = 1000 + hashMod;

    if (affinityScore > 0) {
      baseRank = 1000 + (hashMod % 1500); // closer to 1000-2500
    } else {
      baseRank = 2500 + hashMod * 3; // 2500 to 17500
    }

    // Small bonus for character overlap to feel natural
    const rank = Math.max(1001, Math.floor(baseRank - (charRatio * 300)));

    return {
      word: guess,
      rank: rank,
      color: "red",
      percentage: this.calculatePercentage(rank),
      isWin: false
    };
  }

  // Calculate visual progress percentage (Contexto style)
  // Rank 1 = 100%
  // Rank 500 = ~65%
  // Rank 1000 = ~40%
  // Rank 5000 = ~15%
  // Rank 15000+ = ~5%
  calculatePercentage(rank) {
    if (rank <= 1) return 100;
    if (rank <= 500) {
      // 100% down to 65%
      return Math.round(100 - ((rank - 1) / 500) * 35);
    }
    if (rank <= 1000) {
      // 65% down to 40%
      return Math.round(65 - ((rank - 500) / 500) * 25);
    }
    if (rank <= 5000) {
      // 40% down to 15%
      return Math.round(40 - ((rank - 1000) / 4000) * 25);
    }
    // 15% down to 3%
    const p = 15 - Math.min(12, Math.floor((rank - 5000) / 3000));
    return Math.max(3, p);
  }

  // Generate a helpful hint based on current state
  getHint(secretWordObj, currentBestRank, hintCount = 0) {
    const hints = [];

    // Clue 1: Category & Nature
    hints.push({
      type: "property",
      title: "Category & Nature Clue",
      text: `It is in the category of "${secretWordObj.category.toUpperCase()}" (${secretWordObj.nature}).`
    });

    // Clue 2: Color and Shape
    hints.push({
      type: "property",
      title: "Visual Appearance Clue",
      text: `Color: ${secretWordObj.color} | Typical Shape: ${secretWordObj.shape}.`
    });

    // Clue 3: Characteristics
    hints.push({
      type: "property",
      title: "Characteristics Clue",
      text: `Key traits: ${secretWordObj.characteristics}.`
    });

    // Clue 4+: Word Hint (reveals a helpful word ranked closer than current rank)
    let candidateWord = null;
    if (currentBestRank > 500) {
      // Pick a moderate or close word
      const pool = [...secretWordObj.tiers.orange_moderate, ...secretWordObj.tiers.green_close];
      candidateWord = pool[Math.floor(Math.random() * pool.length)];
    } else {
      // Pick an immediate word
      const pool = secretWordObj.tiers.green_immediate;
      candidateWord = pool[Math.floor(Math.random() * pool.length)];
    }

    if (candidateWord) {
      const evalWord = this.evaluateGuess(candidateWord, secretWordObj);
      hints.push({
        type: "word",
        title: "Word Hint",
        text: `Try thinking about words like "${candidateWord}" (Rank #${evalWord.rank})!`,
        suggestedWord: candidateWord,
        suggestedRank: evalWord.rank
      });
    }

    const index = Math.min(hintCount, hints.length - 1);
    return hints[index];
  }
}

module.exports = new SemanticEngine();
