const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const { Server } = require('socket.io');

const semanticEngine = require('./semanticEngine');
const gameManager = require('./gameManager');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ==========================================
// REST API FOR SOLO MODE
// ==========================================
const soloSessions = new Map(); // sessionId -> { secretWord, guesses, hintsCount, startTime }

// Start new solo game
app.post('/api/solo/start', (req, res) => {
  const sessionId = 'solo_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
  const secretWordObj = semanticEngine.getRandomSecretWord();

  soloSessions.set(sessionId, {
    secretWord: secretWordObj,
    guesses: [],
    hintsCount: 0,
    startTime: Date.now(),
    won: false
  });

  res.json({
    success: true,
    sessionId,
    message: "Solo game started! Try guessing the secret word."
  });
});

// Submit a guess in solo mode
app.post('/api/solo/guess', (req, res) => {
  const { sessionId, word } = req.body;
  const session = soloSessions.get(sessionId);

  if (!session) {
    return res.status(404).json({ error: "Session expired or not found. Please restart game." });
  }

  const evaluation = semanticEngine.evaluateGuess(word, session.secretWord);
  if (evaluation.error) {
    return res.status(400).json({ error: evaluation.error });
  }

  // Record guess if not already guessed
  const exists = session.guesses.some(g => g.word === evaluation.word);
  if (!exists) {
    session.guesses.push(evaluation);
  }

  // Sort guesses by rank ascending
  session.guesses.sort((a, b) => a.rank - b.rank);

  let winStats = null;
  if (evaluation.isWin && !session.won) {
    session.won = true;
    winStats = {
      secretWord: session.secretWord.word,
      timeTakenSec: Math.max(1, Math.round((Date.now() - session.startTime) / 1000)),
      totalGuesses: session.guesses.length,
      hintsTaken: session.hintsCount,
      properties: evaluation.properties
    };
  }

  res.json({
    success: true,
    evaluation,
    guesses: session.guesses,
    guessesCount: session.guesses.length,
    hintsCount: session.hintsCount,
    bestRank: session.guesses[0].rank,
    winStats
  });
});

// Take a hint in solo mode
app.post('/api/solo/hint', (req, res) => {
  const { sessionId } = req.body;
  const session = soloSessions.get(sessionId);

  if (!session) {
    return res.status(404).json({ error: "Session not found." });
  }

  session.hintsCount++;
  const bestRank = session.guesses.length > 0 ? session.guesses[0].rank : 99999;
  const hint = semanticEngine.getHint(session.secretWord, bestRank, session.hintsCount - 1);

  res.json({
    success: true,
    hint,
    hintsCount: session.hintsCount
  });
});

// Solo game stats / surrender info
app.post('/api/solo/giveup', (req, res) => {
  const { sessionId } = req.body;
  const session = soloSessions.get(sessionId);

  if (!session) {
    return res.status(404).json({ error: "Session not found." });
  }

  res.json({
    success: true,
    secretWord: session.secretWord.word,
    properties: {
      category: session.secretWord.category,
      nature: session.secretWord.nature,
      shape: session.secretWord.shape,
      color: session.secretWord.color,
      characteristics: session.secretWord.characteristics
    }
  });
});

// REST: Check if a room code is valid (used by client for instant feedback)
app.get('/api/room/:code', (req, res) => {
  const code = (req.params.code || '').trim().toUpperCase();
  const room = gameManager.rooms.get(code);
  if (!room) {
    return res.status(404).json({ exists: false, error: `Room "${code}" not found. Check the code and try again.` });
  }
  res.json({
    exists: true,
    code: room.code,
    status: room.status,
    playersCount: room.players.size,
    maxPlayers: room.settings.maxPlayers,
    isFull: room.players.size >= room.settings.maxPlayers
  });
});

// ==========================================
// SOCKET.IO FOR REAL-TIME MULTIPLAYER
// ==========================================
io.on('connection', (socket) => {
  // 1. Create Private Room
  socket.on('create_room', (data, callback) => {
    try {
      const { hostName, hostAvatar, maxPlayers, totalRounds, pointsSystem } = data || {};
      const room = gameManager.createRoom({
        hostId: socket.id,
        hostName,
        hostAvatar,
        isRandom: false,
        maxPlayers,
        totalRounds,
        pointsSystem
      });

      socket.join(room.code);
      if (typeof callback === 'function') {
        callback({
          success: true,
          room: gameManager.serializeRoom(room, socket.id)
        });
      }
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 2. Join Private Room
  socket.on('join_room', (data, callback) => {
    try {
      const { roomCode, playerName, playerAvatar } = data || {};
      const result = gameManager.joinRoom({
        roomId: roomCode,
        playerId: socket.id,
        playerName,
        playerAvatar
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      socket.join(result.room.code);

      // Notify others in room
      io.to(result.room.code).emit('room_updated', {
        room: gameManager.serializeRoom(result.room),
        systemMessage: `${playerName || 'A player'} joined the lobby.`
      });

      if (typeof callback === 'function') {
        callback({
          success: true,
          room: gameManager.serializeRoom(result.room, socket.id),
          isHost: result.isHost
        });
      }
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 3. Join Random Room (Quickmatch)
  socket.on('join_random', (data, callback) => {
    try {
      const { playerName, playerAvatar } = data || {};
      const result = gameManager.findOrCreateRandomRoom({
        playerId: socket.id,
        playerName,
        playerAvatar
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      socket.join(result.room.code);

      io.to(result.room.code).emit('room_updated', {
        room: gameManager.serializeRoom(result.room),
        systemMessage: `${playerName || 'A player'} joined the room.`
      });

      if (typeof callback === 'function') {
        callback({
          success: true,
          room: gameManager.serializeRoom(result.room, socket.id),
          isHost: result.isHost
        });
      }
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 4. Update Settings (Admin Only)
  socket.on('update_settings', (data, callback) => {
    try {
      const { roomCode, settings } = data || {};
      const result = gameManager.updateSettings({
        roomId: roomCode,
        adminId: socket.id,
        settings
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      io.to(roomCode).emit('room_updated', {
        room: gameManager.serializeRoom(result.room),
        systemMessage: `Room settings updated by host.`
      });

      if (typeof callback === 'function') callback({ success: true });
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 5. Start Game (Admin Only)
  socket.on('start_game', (data, callback) => {
    try {
      const { roomCode } = data || {};
      const result = gameManager.startGame({
        roomId: roomCode,
        adminId: socket.id
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      // Broadcast game started to all players in the room
      io.to(roomCode).emit('game_started', {
        room: gameManager.serializeRoom(result.room)
      });

      if (typeof callback === 'function') callback({ success: true });
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 6. Submit Guess in Multiplayer Game
  socket.on('submit_guess', (data, callback) => {
    try {
      const { roomCode, word } = data || {};
      const result = gameManager.submitGuess({
        roomId: roomCode,
        playerId: socket.id,
        guessWord: word
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      // Send private guess result & player's full sorted guess list back to sender
      if (typeof callback === 'function') {
        callback({
          success: true,
          evaluation: result.evaluation,
          guesses: result.player.guesses,
          guessesCount: result.player.guessesCount,
          hintsCount: result.player.hintsCount
        });
      }

      // Broadcast updated leaderboard to all players in the room
      io.to(roomCode).emit('leaderboard_updated', {
        leaderboard: gameManager.getLeaderboard(result.room),
        playerUpdate: {
          playerId: result.player.id,
          name: result.player.name,
          bestRank: result.player.currentBestRank,
          guessesCount: result.player.guessesCount,
          hasWon: result.player.hasWonRound
        }
      });

      // If round ended because of winning guess (#1)
      if (result.roundEnded) {
        io.to(roomCode).emit('round_winner', {
          winner: result.roundWinner,
          leaderboard: result.roundStats,
          room: gameManager.serializeRoom(result.room)
        });
      }
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 7. Request Hint in Multiplayer
  socket.on('request_hint', (data, callback) => {
    try {
      const { roomCode } = data || {};
      const result = gameManager.getHintForPlayer({
        roomId: roomCode,
        playerId: socket.id
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      if (typeof callback === 'function') {
        callback({
          success: true,
          hint: result.hint,
          hintsCount: result.hintsCount
        });
      }
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 8. Next Round (Admin Only)
  socket.on('next_round', (data, callback) => {
    try {
      const { roomCode } = data || {};
      const result = gameManager.nextRound({
        roomId: roomCode,
        adminId: socket.id
      });

      if (result.error) {
        if (typeof callback === 'function') callback({ error: result.error });
        return;
      }

      if (result.gameOver) {
        io.to(roomCode).emit('game_over', {
          finalLeaderboard: result.finalLeaderboard,
          room: gameManager.serializeRoom(result.room)
        });
      } else {
        io.to(roomCode).emit('new_round_started', {
          currentRound: result.room.currentRound,
          totalRounds: result.room.settings.totalRounds,
          room: gameManager.serializeRoom(result.room)
        });
      }

      if (typeof callback === 'function') callback({ success: true });
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 9. Send Chat Message (Live human chatting, NO BOTS)
  socket.on('send_chat', (data, callback) => {
    try {
      const { roomCode, text } = data || {};
      const msg = gameManager.addChatMessage({
        roomId: roomCode,
        playerId: socket.id,
        text
      });

      if (msg) {
        io.to(roomCode).emit('chat_message', msg);
        if (typeof callback === 'function') callback({ success: true });
      }
    } catch (err) {
      if (typeof callback === 'function') callback({ error: err.message });
    }
  });

  // 10. Disconnect
  socket.on('disconnect', () => {
    const result = gameManager.removePlayer(socket.id);
    if (result && !result.empty) {
      io.to(result.room.code).emit('room_updated', {
        room: gameManager.serializeRoom(result.room),
        systemMessage: `${result.leavingPlayer ? result.leavingPlayer.name : 'A player'} disconnected.`
      });

      if (result.newAdmin) {
        io.to(result.room.code).emit('admin_changed', {
          newAdminId: result.newAdmin.id,
          newAdminName: result.newAdmin.name
        });
      }
    }
  });
});

// Single Page App routing fallback: /solo, /multiplayer, /
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

const { exec } = require('child_process');

function startServer(port = 3000, attempts = 0) {
  if (attempts > 10) {
    console.error('Could not find an open port after 10 attempts.');
    process.exit(1);
  }

  server.once('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`Port ${port} is currently in use. Trying port ${port + 1}...`);
      startServer(port + 1, attempts + 1);
    } else {
      console.error('Server error:', err);
    }
  });

  server.listen(port, () => {
    console.log(`===============================================`);
    console.log(`🚀 Wordlerz Guess Game server running at http://localhost:${port}`);
    console.log(`✨ Solo mode: http://localhost:${port}/solo`);
    console.log(`🎮 Multiplayer: http://localhost:${port}/multiplayer`);
    console.log(`===============================================`);

    // Auto-open browser on Windows if not running in test mode
    if (process.platform === 'win32' && !process.env.NO_AUTO_OPEN) {
      exec(`start http://localhost:${port}`);
    }
  });
}

const START_PORT = parseInt(process.env.PORT, 10) || 3000;
startServer(START_PORT);
