const semanticEngine = require('./semanticEngine');

class GameManager {
  constructor() {
    // Map of roomId -> room object
    this.rooms = new Map();
    // Map of socketId -> { roomId, playerId }
    this.playerSessions = new Map();
  }

  // Generate a random 6-character room code (e.g. CTX924)
  generateRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Create a new room
  createRoom({ hostId, hostName, hostAvatar, isRandom = false, maxPlayers = 8, totalRounds = 3, pointsSystem = 'standard' }) {
    let roomCode = this.generateRoomCode();
    while (this.rooms.has(roomCode)) {
      roomCode = this.generateRoomCode();
    }

    const secretWordObj = semanticEngine.getRandomSecretWord();

    const room = {
      id: roomCode,
      code: roomCode,
      isRandom,
      adminId: hostId,
      status: 'lobby', // 'lobby' | 'playing' | 'round_ended' | 'game_over'
      settings: {
        maxPlayers: Math.max(2, Math.min(20, parseInt(maxPlayers) || 8)),
        totalRounds: Math.max(1, Math.min(10, parseInt(totalRounds) || 3)),
        pointsSystem: pointsSystem || 'standard' // 'standard' (100, 70, 50, 30) or 'fast' (100 - guesses)
      },
      currentRound: 1,
      secretWord: secretWordObj,
      roundStartTime: null,
      roundWinner: null,
      players: new Map(), // playerId -> player
      chatMessages: []
    };

    // Add host as first player
    const hostPlayer = {
      id: hostId,
      socketId: hostId,
      name: hostName || 'Player 1',
      avatar: hostAvatar || 'avatar_1',
      isAdmin: true,
      score: 0,
      currentBestRank: 99999,
      guessesCount: 0,
      hintsCount: 0,
      hasWonRound: false,
      guesses: []
    };

    room.players.set(hostId, hostPlayer);
    this.rooms.set(roomCode, room);
    this.playerSessions.set(hostId, { roomId: roomCode, playerId: hostId });

    return room;
  }

  // Find or create an open public random room
  findOrCreateRandomRoom({ playerId, playerName, playerAvatar }) {
    for (const [code, room] of this.rooms.entries()) {
      if (room.isRandom && room.status === 'lobby' && room.players.size < room.settings.maxPlayers) {
        return this.joinRoom({ roomId: code, playerId, playerName, playerAvatar });
      }
    }

    // No open random room, create one!
    return {
      room: this.createRoom({
        hostId: playerId,
        hostName: playerName,
        hostAvatar: playerAvatar,
        isRandom: true,
        maxPlayers: 8,
        totalRounds: 3
      }),
      isHost: true
    };
  }

  // Join an existing room
  joinRoom({ roomId, playerId, playerName, playerAvatar }) {
    const code = (roomId || '').trim().toUpperCase();
    const room = this.rooms.get(code);

    if (!room) {
      return { error: `Room ${code} not found.` };
    }

    if (room.players.size >= room.settings.maxPlayers) {
      return { error: 'Room is already full.' };
    }

    // Check if player already in room (reconnect or new)
    let player = room.players.get(playerId);
    if (!player) {
      player = {
        id: playerId,
        socketId: playerId,
        name: playerName || `Player ${room.players.size + 1}`,
        avatar: playerAvatar || 'avatar_1',
        isAdmin: room.adminId === playerId,
        score: 0,
        currentBestRank: 99999,
        guessesCount: 0,
        hintsCount: 0,
        hasWonRound: false,
        guesses: []
      };
      room.players.set(playerId, player);
    } else {
      player.socketId = playerId;
      player.name = playerName || player.name;
      player.avatar = playerAvatar || player.avatar;
    }

    this.playerSessions.set(playerId, { roomId: code, playerId });

    return { room, isHost: room.adminId === playerId };
  }

  // Update room settings (admin only)
  updateSettings({ roomId, adminId, settings }) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: 'Room not found' };
    if (room.adminId !== adminId) return { error: 'Only admin can change settings' };

    if (settings.maxPlayers) {
      room.settings.maxPlayers = Math.max(2, Math.min(20, parseInt(settings.maxPlayers)));
    }
    if (settings.totalRounds) {
      room.settings.totalRounds = Math.max(1, Math.min(10, parseInt(settings.totalRounds)));
    }
    if (settings.pointsSystem) {
      room.settings.pointsSystem = settings.pointsSystem;
    }

    return { room };
  }

  // Start the game (admin only)
  startGame({ roomId, adminId }) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: 'Room not found' };
    if (room.adminId !== adminId) return { error: 'Only the host admin can start the game' };

    room.status = 'playing';
    room.roundStartTime = Date.now();
    room.roundWinner = null;
    room.secretWord = semanticEngine.getRandomSecretWord();

    // Reset player round stats
    for (const player of room.players.values()) {
      player.currentBestRank = 99999;
      player.guessesCount = 0;
      player.hintsCount = 0;
      player.hasWonRound = false;
      player.guesses = [];
    }

    return { room };
  }

  // Player submits a guess in multiplayer
  submitGuess({ roomId, playerId, guessWord }) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: 'Room not found' };
    if (room.status !== 'playing') return { error: 'Game is not currently active' };

    const player = room.players.get(playerId);
    if (!player) return { error: 'Player not in room' };

    const evaluation = semanticEngine.evaluateGuess(guessWord, room.secretWord);
    if (evaluation.error) return { error: evaluation.error };

    player.guessesCount++;

    // Check if already guessed this word in this round
    const existingIndex = player.guesses.findIndex(g => g.word === evaluation.word);
    if (existingIndex === -1) {
      player.guesses.push(evaluation);
    }

    // Sort player's guesses ascending by rank (rank 1 at top)
    player.guesses.sort((a, b) => a.rank - b.rank);

    if (evaluation.rank < player.currentBestRank) {
      player.currentBestRank = evaluation.rank;
    }

    let roundEnded = false;
    let roundStats = null;

    // Check if Win! (Rank 1)
    if (evaluation.isWin && !player.hasWonRound) {
      player.hasWonRound = true;
      room.roundWinner = {
        playerId: player.id,
        playerName: player.name,
        playerAvatar: player.avatar,
        timeTakenSec: Math.max(1, Math.round((Date.now() - room.roundStartTime) / 1000)),
        totalGuesses: player.guessesCount,
        hintsTaken: player.hintsCount,
        secretWord: room.secretWord.word
      };

      // Award points
      if (room.settings.pointsSystem === 'fast') {
        const bonus = Math.max(10, 100 - player.guessesCount * 2);
        player.score += bonus;
      } else {
        player.score += 100;
      }

      room.status = 'round_ended';
      roundEnded = true;

      // Compile round summary stats for all players
      roundStats = this.getLeaderboard(room);
    }

    return {
      evaluation,
      player,
      roundEnded,
      roundWinner: room.roundWinner,
      roundStats,
      room
    };
  }

  // Player asks for a hint
  getHintForPlayer({ roomId, playerId }) {
    const room = this.rooms.get(roomId);
    if (!room || room.status !== 'playing') return { error: 'Cannot take hint right now' };

    const player = room.players.get(playerId);
    if (!player) return { error: 'Player not found' };

    player.hintsCount++;
    const hint = semanticEngine.getHint(room.secretWord, player.currentBestRank, player.hintsCount - 1);
    return { hint, hintsCount: player.hintsCount };
  }

  // Next round or complete match
  nextRound({ roomId, adminId }) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: 'Room not found' };
    if (room.adminId !== adminId) return { error: 'Only admin can start next round' };

    if (room.currentRound >= room.settings.totalRounds) {
      room.status = 'game_over';
      return { room, gameOver: true, finalLeaderboard: this.getLeaderboard(room) };
    }

    room.currentRound++;
    room.status = 'playing';
    room.roundStartTime = Date.now();
    room.roundWinner = null;
    room.secretWord = semanticEngine.getRandomSecretWord();

    for (const player of room.players.values()) {
      player.currentBestRank = 99999;
      player.guessesCount = 0;
      player.hintsCount = 0;
      player.hasWonRound = false;
      player.guesses = [];
    }

    return { room, gameOver: false };
  }

  // Add a chat message
  addChatMessage({ roomId, playerId, text }) {
    const room = this.rooms.get(roomId);
    if (!room) return null;

    const player = room.players.get(playerId);
    const senderName = player ? player.name : 'Spectator';
    const senderAvatar = player ? player.avatar : 'avatar_1';

    const msg = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      senderId: playerId,
      senderName,
      senderAvatar,
      text: (text || '').trim().substring(0, 200),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    room.chatMessages.push(msg);
    if (room.chatMessages.length > 100) room.chatMessages.shift();

    return msg;
  }

  // Remove player on disconnect
  removePlayer(socketId) {
    const session = this.playerSessions.get(socketId);
    if (!session) return null;

    const { roomId, playerId } = session;
    this.playerSessions.delete(socketId);

    const room = this.rooms.get(roomId);
    if (!room) return null;

    const leavingPlayer = room.players.get(playerId);
    room.players.delete(playerId);

    let newAdmin = null;
    if (room.adminId === playerId && room.players.size > 0) {
      // Pass admin to next player
      const nextPlayer = room.players.values().next().value;
      room.adminId = nextPlayer.id;
      nextPlayer.isAdmin = true;
      newAdmin = nextPlayer;
    }

    if (room.players.size === 0) {
      this.rooms.delete(roomId);
      return { roomCode: roomId, empty: true };
    }

    return {
      room,
      leavingPlayer,
      newAdmin
    };
  }

  // Leaderboard sorted by score then best rank
  getLeaderboard(room) {
    const playersList = Array.from(room.players.values()).map(p => ({
      id: p.id,
      name: p.name,
      avatar: p.avatar,
      score: p.score,
      currentBestRank: p.currentBestRank === 99999 ? '-' : p.currentBestRank,
      guessesCount: p.guessesCount,
      hintsCount: p.hintsCount,
      hasWonRound: p.hasWonRound
    }));

    playersList.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if (a.currentBestRank === '-' && b.currentBestRank !== '-') return 1;
      if (b.currentBestRank === '-' && a.currentBestRank !== '-') return -1;
      return (a.currentBestRank || 99999) - (b.currentBestRank || 99999);
    });

    return playersList;
  }

  // Serialized public view of room (without exposing secret word to clients!)
  serializeRoom(room, forPlayerId = null) {
    if (!room) return null;

    const playersList = Array.from(room.players.values()).map(p => ({
      id: p.id,
      name: p.name,
      avatar: p.avatar,
      isAdmin: p.isAdmin,
      score: p.score,
      currentBestRank: p.currentBestRank === 99999 ? '-' : p.currentBestRank,
      guessesCount: p.guessesCount,
      hintsCount: p.hintsCount,
      hasWonRound: p.hasWonRound,
      isSelf: p.id === forPlayerId
    }));

    // Find requesting player's guesses
    const selfPlayer = forPlayerId ? room.players.get(forPlayerId) : null;
    const myGuesses = selfPlayer ? selfPlayer.guesses : [];

    return {
      id: room.id,
      code: room.code,
      isRandom: room.isRandom,
      status: room.status,
      adminId: room.adminId,
      settings: room.settings,
      currentRound: room.currentRound,
      roundWinner: room.roundWinner,
      players: playersList,
      playersCount: room.players.size,
      myGuesses,
      chatMessages: room.chatMessages.slice(-50)
    };
  }
}

module.exports = new GameManager();
