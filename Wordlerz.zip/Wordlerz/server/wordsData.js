// Curated dictionary of secret words with detailed semantic relationships,
// tiers of closeness (Green 1-500, Orange 501-1000), and semantic attributes.

const SECRET_WORDS = [
  {
    word: "pizza",
    category: "food",
    nature: "edible, baked, prepared meal",
    shape: "round, triangular slice, flat",
    color: "golden, red, white, yellow",
    characteristics: "cheesy, savory, hot, crusty, italian, popular fast food",
    tiers: {
      green_immediate: [
        "calzone", "pepperoni", "mozzarella", "crust", "slice", "dough", "marinara",
        "topping", "pizzeria", "cheese", "sauce", "parmesan", "oregano", "basil",
        "italian", "baked", "oven", "pie", "flatbread", "prosciutto", "ricotta",
        "pasta", "spaghetti", "lasagna", "focaccia", "calzone", "garlic", "tomato"
      ],
      green_close: [
        "restaurant", "delivery", "chef", "dinner", "lunch", "snack", "fastfood",
        "meal", "takeout", "food", "kitchen", "pan", "baking", "flour", "yeast",
        "olive", "mushroom", "onion", "sausage", "bacon", "bread", "cheddar",
        "burger", "sandwich", "fries", "taco", "burrito", "salad", "appetizer",
        "bistro", "recipe", "cook", "dining", "hungry", "delicious", "tasty",
        "slice", "eat", "eating", "box", "order", "menu", "waiter", "plate"
      ],
      orange_moderate: [
        "table", "fork", "knife", "napkin", "drink", "soda", "beer", "wine",
        "party", "gathering", "kitchenette", "counter", "refrigerator", "microwave",
        "stove", "culinary", "groceries", "supermarket", "buffet", "snack",
        "dessert", "cake", "cookie", "chocolate", "soup", "stew", "meatball",
        "vegetable", "fruit", "grain", "wheat", "oil", "pepper", "salt", "spice"
      ]
    }
  },
  {
    word: "ocean",
    category: "nature",
    nature: "elemental, aquatic, natural water body",
    shape: "vast, fluid, deep, rolling waves",
    color: "blue, cyan, turquoise, deep navy",
    characteristics: "salty, immense, wet, tidal, marine, life-giving, storm",
    tiers: {
      green_immediate: [
        "sea", "marine", "water", "wave", "waves", "tide", "coast", "shore",
        "beach", "coral", "reef", "deep", "abyss", "atlantic", "pacific",
        "trench", "current", "swell", "surf", "saltwater", "underwater", "aquatic",
        "whale", "dolphin", "shark", "tsunami", "voyage", "seabed", "nautical"
      ],
      green_close: [
        "fish", "pelican", "seagull", "ship", "boat", "sail", "anchor", "island",
        "submarine", "diving", "scuba", "swimming", "harbor", "port", "navigator",
        "compass", "lighthouse", "bay", "cove", "gulf", "lagoon", "strait",
        "iceberg", "tidepool", "mariner", "sailor", "pirate", "kelp", "algae",
        "plankton", "seahorse", "octopus", "squid", "crab", "lobster", "jellyfish",
        "storm", "hurricane", "horizon", "breeze", "sand", "shell", "driftwood"
      ],
      orange_moderate: [
        "lake", "river", "stream", "pond", "waterfall", "rain", "storm", "cloud",
        "weather", "climate", "globe", "planet", "earth", "continent", "blue",
        "fluid", "liquid", "wet", "drown", "float", "sink", "depth", "pressure",
        "nature", "wildlife", "ecosystem", "environment", "expedition", "voyage"
      ]
    }
  },
  {
    word: "guitar",
    category: "music",
    nature: "manufactured, acoustic, electric instrument",
    shape: "curved body, long neck, fretboard",
    color: "wooden, brown, black, sunburst, metallic",
    characteristics: "musical, melodic, strummed, plucked, resonant, rock",
    tiers: {
      green_immediate: [
        "fret", "string", "strings", "strum", "acoustic", "electric", "bass",
        "chord", "chords", "pick", "fretboard", "tuning", "tuner", "amplifier",
        "solo", "riff", "musician", "instrument", "melodic", "resonance", "banjo",
        "ukulele", "lute", "mandolin", "hendrix", "tablature", "strumming"
      ],
      green_close: [
        "band", "concert", "rock", "jazz", "blues", "folk", "reggae", "music",
        "song", "melody", "rhythm", "beat", "tempo", "drums", "piano", "keyboard",
        "violin", "cello", "flute", "trumpet", "saxophone", "singer", "vocalist",
        "stage", "performance", "album", "studio", "recording", "track", "tune",
        "acoustic", "sound", "harmony", "volume", "loudspeaker", "pedal", "wood"
      ],
      orange_moderate: [
        "art", "entertainment", "dance", "club", "radio", "speaker", "headphones",
        "audio", "microphone", "party", "festival", "creative", "leisure",
        "hobby", "talent", "practice", "lesson", "notes", "composition", "orchestra"
      ]
    }
  },
  {
    word: "volcano",
    category: "nature",
    nature: "geological, planetary, tectonic landform",
    shape: "conical mountain, crater, vent",
    color: "molten red, ash gray, volcanic black, fiery orange",
    characteristics: "explosive, erupting, scalding, destructive, ancient, geothermal",
    tiers: {
      green_immediate: [
        "magma", "lava", "eruption", "crater", "ash", "caldera", "geyser",
        "tectonic", "seismic", "pyroclastic", "geology", "dormant", "active",
        "fissure", "obsidian", "basalt", "pumice", "fumarole", "volcanic",
        "mountain", "mantle", "earthquake", "crust", "pompeii", "molten"
      ],
      green_close: [
        "fire", "heat", "smoke", "rock", "stone", "island", "plateau", "peak",
        "summit", "geology", "mineral", "geothermal", "disaster", "explosion",
        "blast", "hazard", "steam", "sulfur", "crust", "planet", "core", "deep",
        "destructive", "melt", "burning", "flame", "chamber", "cone", "ridge"
      ],
      orange_moderate: [
        "hill", "cliff", "valley", "canyon", "earth", "nature", "landscape",
        "weather", "cloud", "danger", "ashy", "dark", "heavy", "force",
        "energy", "power", "ancient", "science", "geography", "hazard", "shield"
      ]
    }
  },
  {
    word: "telescope",
    category: "science",
    nature: "optical instrument, scientific observation device",
    shape: "cylindrical tube, tripod, lenses",
    color: "metallic, silver, black, white",
    characteristics: "magnifying, celestial, astronomy, distant, stargazing",
    tiers: {
      green_immediate: [
        "astronomy", "observatory", "lens", "stargazing", "optics", "magnification",
        "refractor", "reflector", "hubble", "eyepiece", "focal", "celestial",
        "constellation", "galaxy", "stars", "star", "planet", "planets", "moon",
        "cosmos", "universe", "space", "nebula", "comet", "astronomer", "tripod"
      ],
      green_close: [
        "sky", "night", "astrophysics", "orbit", "satellite", "focus", "mirror",
        "discovery", "science", "laboratory", "physics", "solar", "sun", "mars",
        "jupiter", "saturn", "binoculars", "microscope", "camera", "view", "vision",
        "distance", "zoom", "darkness", "cosmos", "cosmic", "deepspace", "light"
      ],
      orange_moderate: [
        "glass", "metal", "tube", "stand", "instrument", "tool", "device",
        "research", "curiosity", "exploration", "spectacle", "technology", "study",
        "academic", "watch", "sight", "perspective", "measurement", "range"
      ]
    }
  },
  {
    word: "elephant",
    category: "animal",
    nature: "mammal, herbivore, wildlife",
    shape: "massive body, large flapping ears, long flexible trunk, curved tusks",
    color: "gray, earthy, slate",
    characteristics: "intelligent, gentle giant, strong, African, Asian, herd, pachyderm",
    tiers: {
      green_immediate: [
        "trunk", "tusk", "tusks", "mammoth", "ivory", "savanna", "safari",
        "pachyderm", "herd", "mammal", "african", "asian", "jumbo", "ears",
        "bull", "calf", "proboscis", "hide", "matriarch", "stampede"
      ],
      green_close: [
        "animal", "wildlife", "zoo", "jungle", "wild", "nature", "rhino",
        "hippopotamus", "giraffe", "zebra", "lion", "tiger", "bear", "beast",
        "large", "giant", "heavy", "huge", "weight", "walk", "memory",
        "herbivore", "foliage", "sanctuary", "grassland", "endangered", "creature"
      ],
      orange_moderate: [
        "forest", "trees", "waterhole", "mud", "tail", "feet", "legs",
        "earth", "fauna", "biology", "species", "conservation", "circus", "africa", "india"
      ]
    }
  },
  {
    word: "airplane",
    category: "vehicle",
    nature: "manufactured, aeronautical, motorized transport",
    shape: "aerodynamic, fuselage, wings, jet engines",
    color: "white, metallic, silver, painted livery",
    characteristics: "flying, fast, commercial, high-altitude, passenger, cargo",
    tiers: {
      green_immediate: [
        "aircraft", "flight", "plane", "aeroplane", "jet", "pilot", "cockpit",
        "wings", "fuselage", "propeller", "runway", "airport", "hangar",
        "aviation", "altitude", "takeoff", "landing", "boeing", "airbus",
        "airline", "passengers", "stewardess", "turbofan", "autopilot"
      ],
      green_close: [
        "sky", "clouds", "travel", "journey", "helicopter", "rocket", "glide",
        "flying", "speed", "transportation", "ticket", "boarding", "luggage",
        "terminal", "cargo", "international", "continent", "navigation", "radar",
        "engine", "fuel", "cabin", "seatbelt", "air", "airspace", "trip", "voyage"
      ],
      orange_moderate: [
        "vehicle", "machine", "technology", "transport", "metal", "aluminum",
        "wheels", "window", "control", "radio", "commute", "distance", "fast",
        "globe", "world", "holiday", "vacation", "tourism", "hotel", "destination"
      ]
    }
  },
  {
    word: "castle",
    category: "structure",
    nature: "architectural, medieval, fortification, historical",
    shape: "tall stone towers, battlements, moat, drawbridge, courtyard",
    color: "gray stone, weathered granite, mossy rock",
    characteristics: "regal, medieval, defensive, monumental, fortified, royalty",
    tiers: {
      green_immediate: [
        "fortress", "palace", "citadel", "keep", "tower", "moat", "drawbridge",
        "battlement", "rampart", "dungeon", "king", "queen", "royalty", "medieval",
        "knight", "knights", "throne", "monarch", "stonework", "fortification",
        "stronghold", "baron", "chateau", "bastion", "armor", "heraldry"
      ],
      green_close: [
        "stone", "wall", "gate", "shield", "sword", "siege", "catapult", "archery",
        "crossbow", "guards", "crown", "monarchy", "court", "feudal", "history",
        "ancient", "legend", "fairytale", "realm", "kingdom", "empire", "ruler",
        "nobility", "ballroom", "tapestry", "gargoyle", "courtyard", "flag", "banner"
      ],
      orange_moderate: [
        "building", "house", "mansion", "monument", "ruins", "architecture", "estate",
        "country", "war", "battle", "heritage", "tourism", "europe", "granite", "wood",
        "fireplace", "candle", "torch", "grandeur", "past", "centuries", "myth"
      ]
    }
  },
  {
    word: "coffee",
    category: "food",
    nature: "beverage, brewed, caffeinated",
    shape: "liquid in cup, roasted oval beans, grounds",
    color: "dark brown, espresso black, caramel, creamy",
    characteristics: "caffeinated, aromatic, bitter, steaming hot, energizing, morning staple",
    tiers: {
      green_immediate: [
        "espresso", "caffeine", "latte", "cappuccino", "brew", "roast", "beans",
        "barista", "mug", "cafe", "cup", "crema", "mocha", "americano", "macchiato",
        "filter", "steamer", "grinder", "roastery", "frenchpress", "arabica", "robusta"
      ],
      green_close: [
        "morning", "wake", "energy", "breakfast", "tea", "drink", "beverage",
        "hot", "warm", "steam", "sugar", "milk", "cream", "foam", "sipping",
        "pot", "kettle", "smell", "flavor", "aroma", "pastry", "croissant", "donut",
        "coffeehouse", "starbucks", "table", "break", "routine", "refreshing"
      ],
      orange_moderate: [
        "spoon", "saucer", "kitchen", "cafe", "shop", "dessert", "water", "food",
        "snack", "office", "work", "meeting", "social", "relax", "liquid", "taste",
        "chocolate", "cocoa", "glass", "paper", "thermos", "liquid"
      ]
    }
  },
  {
    word: "diamond",
    category: "mineral",
    nature: "geological, crystalline, gemstone, carbon",
    shape: "faceted, brilliant cut, geometric crystal",
    color: "transparent, glittering, sparkling, prism reflections",
    characteristics: "hardest, precious, sparkling, luxury, rare, enduring",
    tiers: {
      green_immediate: [
        "gem", "gemstone", "jewel", "jewelry", "crystal", "carbon", "brilliant",
        "sparkle", "carat", "karat", "facet", "precious", "ring", "necklace",
        "engagement", "emerald", "ruby", "sapphire", "quartz", "luster", "hardness"
      ],
      green_close: [
        "gold", "silver", "platinum", "luxury", "wealth", "expensive", "treasure",
        "vault", "cleavage", "clarity", "cut", "color", "polish", "shine",
        "prism", "refraction", "mined", "mine", "geology", "stone", "rock",
        "gift", "bride", "wedding", "glamour", "royalty", "ornament", "valuable"
      ],
      orange_moderate: [
        "earth", "pressure", "deep", "ancient", "glass", "metallic", "mineral",
        "science", "atom", "lattice", "mirror", "beauty", "rarity", "market",
        "crown", "tiara", "bracelet", "accessory", "fashion", "glitter"
      ]
    }
  },
  {
    word: "dolphin",
    category: "animal",
    nature: "marine mammal, cetacean, aquatic life",
    shape: "streamlined, dorsal fin, curved beak, flukes",
    color: "sleek gray, pale underside, glossy",
    characteristics: "intelligent, playful, agile, echolocation, leaping, social pod",
    tiers: {
      green_immediate: [
        "porpoise", "whale", "orca", "cetacean", "blowhole", "fin", "fluke",
        "pod", "echolocation", "flipper", "marine", "mammal", "sea", "ocean",
        "aquatic", "swim", "swimmer", "leaping", "snout", "playful"
      ],
      green_close: [
        "shark", "seal", "otter", "fish", "water", "waves", "reef", "coral",
        "coast", "surf", "underwater", "creature", "animal", "wildlife",
        "intelligence", "acrobatic", "trainer", "aquarium", "diving", "blue",
        "deep", "saltwater", "speed", "friendly", "whistle", "sonar"
      ],
      orange_moderate: [
        "boat", "ship", "island", "nature", "biology", "species", "safari",
        "oceanic", "sunlight", "splash", "tail", "mammalian", "school", "beach"
      ]
    }
  },
  {
    word: "forest",
    category: "nature",
    nature: "terrestrial ecosystem, dense woodland",
    shape: "canopy of branches, tall trunks, dense undergrowth",
    color: "green, emerald, earthy brown, mossy",
    characteristics: "lush, woodsy, biodiverse, quiet, ancient, wild, oxygenating",
    tiers: {
      green_immediate: [
        "woods", "woodland", "trees", "tree", "jungle", "rainforest", "grove",
        "timber", "canopy", "foliage", "leaves", "pine", "oak", "branches",
        "bark", "undergrowth", "taiga", "wilderness", "flora", "moss"
      ],
      green_close: [
        "nature", "wildlife", "animal", "deer", "bear", "owl", "wolf", "fox",
        "trail", "path", "hiking", "camp", "roots", "sapling", "fern",
        "mushroom", "fungus", "clearing", "cabin", "ranger", "nationalpark",
        "soil", "earth", "shade", "quiet", "breeze", "ecosystem", "environment"
      ],
      orange_moderate: [
        "mountain", "river", "stream", "lake", "valley", "wood", "lumber", "axe",
        "firewood", "green", "outdoor", "landscape", "planet", "planet", "air",
        "oxygen", "season", "autumn", "spring", "rain", "fog"
      ]
    }
  }
];

// Broad vocabulary categories to provide realistic semantic clustering for any English word
const CATEGORY_CLUSTERS = {
  food: ["edible", "eat", "taste", "flavor", "cook", "kitchen", "snack", "sweet", "sour", "spicy", "fruit", "vegetable", "meat", "dish", "bakery", "recipe", "drink", "dining", "fork", "plate"],
  nature: ["water", "earth", "air", "sky", "plant", "tree", "soil", "mountain", "river", "lake", "stone", "cloud", "sun", "rain", "weather", "wild", "forest", "sea", "climate", "valley"],
  animal: ["creature", "mammal", "bird", "reptile", "insect", "predator", "prey", "claws", "fur", "feathers", "tail", "wildlife", "pet", "species", "zoo", "safari", "organism", "living"],
  music: ["sound", "melody", "rhythm", "instrument", "audio", "song", "tune", "beat", "voice", "singing", "harmony", "band", "concert", "notes", "tempo", "acoustic", "loudspeaker"],
  science: ["physics", "chemistry", "biology", "space", "optics", "energy", "experiment", "laboratory", "theory", "device", "study", "formula", "molecule", "atom", "technology"],
  vehicle: ["wheels", "engine", "motor", "drive", "travel", "road", "speed", "transport", "passenger", "ride", "fuel", "cabin", "steering", "gear", "cargo", "journey"],
  structure: ["building", "wall", "roof", "room", "door", "window", "brick", "stone", "house", "tower", "architecture", "monument", "foundation", "beam", "hall"],
  mineral: ["crystal", "stone", "rock", "geology", "gem", "mine", "ore", "carbon", "luster", "precious", "metal", "hard", "solid", "strata"]
};

module.exports = {
  SECRET_WORDS,
  CATEGORY_CLUSTERS
};
